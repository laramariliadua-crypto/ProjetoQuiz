import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Cabeçalho do sistema
        System.out.println("==============================================");
        System.out.println("                  QUIZ JAVA                  ");
        System.out.println("Aluna: Lara Marília Eugênia Fernandes");
        System.out.println("Professor: Bruno");
        System.out.println("Faculdade: UNIFAN Alfredo Nasser");
        System.out.println("==============================================");

        // Lista com as 15 questões do quiz
        List<Questao> questoes = new ArrayList<>();

        questoes.add(new Questao(
                "Qual linguagem de programacao este projeto utiliza?",
                new String[]{"Python", "Java", "C#", "JavaScript"}, 2));

        questoes.add(new Questao(
                "Qual palavra-chave e usada para declarar uma classe em Java?",
                new String[]{"class", "function", "define", "struct"}, 1));

        questoes.add(new Questao(
                "Qual tipo primitivo armazena numeros inteiros?",
                new String[]{"String", "boolean", "int", "char"}, 3));

        questoes.add(new Questao(
                "Qual comando exibe uma mensagem no console?",
                new String[]{"Scanner", "System.out.println", "import", "return"}, 2));

        questoes.add(new Questao(
                "Qual estrutura repete comandos enquanto uma condicao for verdadeira?",
                new String[]{"if", "class", "while", "switch"}, 3));

        questoes.add(new Questao(
                "Qual operador verifica se dois valores sao iguais?",
                new String[]{"=", "==", "!=", "+"}, 2));

        questoes.add(new Questao(
                "Qual tipo primitivo representa verdadeiro ou falso?",
                new String[]{"int", "String", "double", "boolean"}, 4));

        questoes.add(new Questao(
                "Qual estrutura e usada para testar uma condicao?",
                new String[]{"if", "package", "import", "new"}, 1));

        questoes.add(new Questao(
                "Qual classe pode ler dados digitados pelo usuario?",
                new String[]{"Math", "Scanner", "String", "System"}, 2));

        questoes.add(new Questao(
                "Qual palavra-chave e usada para criar um objeto?",
                new String[]{"object", "make", "new", "create"}, 3));

        questoes.add(new Questao(
                "Qual classe de colecao pode armazenar uma lista de objetos?",
                new String[]{"ArrayList", "Integer", "Boolean", "Character"}, 1));

        questoes.add(new Questao(
                "Qual operador logico representa a operacao E?",
                new String[]{"||", "!", "&&", "=="}, 3));

        questoes.add(new Questao(
                "Qual palavra-chave pode devolver um valor de um metodo?",
                new String[]{"break", "return", "continue", "import"}, 2));

        questoes.add(new Questao(
                "Qual tipo primitivo e comumente usado para numeros decimais com maior precisao?",
                new String[]{"int", "char", "boolean", "double"}, 4));

        questoes.add(new Questao(
                "Qual estrutura permite selecionar entre diferentes casos?",
                new String[]{"switch", "while", "for", "do"}, 1));

        int acertos = 0;

        // Apresenta as perguntas e verifica as respostas
        for (int i = 0; i < questoes.size(); i++) {
            Questao questao = questoes.get(i);

            System.out.println("\n" + (i + 1) + ". " + questao.getEnunciado());
            String[] alternativas = questao.getAlternativas();

            for (int j = 0; j < alternativas.length; j++) {
                System.out.println((j + 1) + " - " + alternativas[j]);
            }

            int resposta = 0;
            while (resposta < 1 || resposta > alternativas.length) {
                System.out.print("Digite sua resposta (1 a 4): ");

                if (scanner.hasNextInt()) {
                    resposta = scanner.nextInt();
                    if (resposta < 1 || resposta > alternativas.length) {
                        System.out.println("Opcao invalida. Escolha um numero de 1 a 4.");
                    }
                } else {
                    System.out.println("Entrada invalida. Digite um numero de 1 a 4.");
                    scanner.next();
                }
            }

            if (resposta == questao.getRespostaCorreta()) {
                System.out.println("Resposta correta!");
                acertos++;
            } else {
                System.out.println("Resposta incorreta!");
            }
        }

        double porcentagem = (acertos * 100.0) / questoes.size();

        // Exibe o resultado final
        System.out.println("\n==============================================");
        System.out.println("                 RESULTADO FINAL              ");
        System.out.println("==============================================");
        System.out.println("Total de questoes: " + questoes.size());
        System.out.println("Total de acertos: " + acertos);
        System.out.printf(Locale.forLanguageTag("pt-BR"),
                "Porcentagem de acertos: %.2f%%%n", porcentagem);
        System.out.println("Obrigada por participar do Quiz!");
        System.out.println("==============================================");

        scanner.close();
    }
}
